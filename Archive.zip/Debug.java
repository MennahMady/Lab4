public class Debug {
    // set DEBUG to false to compile out debug code
    public static final boolean DEBUG = true;
}